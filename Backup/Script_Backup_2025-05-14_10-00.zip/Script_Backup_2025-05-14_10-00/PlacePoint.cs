using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlacePoint : MonoBehaviour
{
    [HideInInspector]
    public bool isOccupied = false;
}
